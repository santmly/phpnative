<?php
defined('BASEPATH') or exit('No direct script access allowed');

class daily extends CI_Controller
{
    public function index()
    {
        $this->load->model('m_daily');

        $ddata['title'] = 'Daily Checklist';

        $ddata['user'] = $this->db->get_where('a_user_account', ['email' => $this->session->userdata('email')])->row_array();
        $ddata['table'] = $this->m_daily->generate();

        $this->db->where('date', date('Y-m-d'));
        $ddata['isitabel'] = $this->db->select('nopol, date, presentase')->from('jadwal')->get();
        $this->load->view('user/v_daily', $ddata);
    }
}
