<?php
defined('BASEPATH') or exit('No direct script access allowed');

use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\TemplateProcessor;
use PhpOffice\PhpWord\Shared\Converter;
use PhpOffice\PhpWord\Style\TablePosition;
use PhpOffice\PhpWord\Settings;

class Download extends CI_Controller
{

    public function Summary()
    {
        \PhpOffice\PhpWord\Settings::setOutputEscapingEnabled(true);
        $np = $this->uri->segment(3);
        $nopol = urldecode($np);

        $this->load->model('simb_model');
        $jadwal = $this->simb_model->getJadwal($nopol);
        $isi = $this->simb_model->getDetail($nopol);
        //$now = date('d-m-Y');

        $export = 'word';
        // $template = new TemplateProcessor(base_url().'assets/doc-templates/sppd-dep-baru.docx');
        $template = new TemplateProcessor(base_url() . '/assets/document-template/summary.docx');
        $template->setValue('nopol', $nopol);
        // $template->setValue('berlaku_sampai_tanggal', '1');
        // $template->setValue('kondisi', '1');
        // $template->setValue('dispensasi', '2');
        // $template->setValue('lama_dispensasi', '3');
        // $template->setValue('keterangan', '4');

        $filename = 'SUMMARY-' . $nopol  . '.docx';

        switch ($export) {
            case 'word':
                header("Content-Description: File Transfer");
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
                header('Content-Transfer-Encoding: binary');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Expires: 0');
                $template->saveAs("php://output");
                break;
            case 'excel':
                // Redirect output to a client’s web browser (Xlsx)
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="' . $filename . '"');
                header('Cache-Control: max-age=0');
                // If you're serving to IE 9, then the following may be needed
                header('Cache-Control: max-age=1');
                // If you're serving to IE over SSL, then the following may be needed
                header('Expires: 0');
                header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
                header('Pragma: public'); // HTTP/1.0
                $writer = IOFactory::createWriter($template, 'Xlsx');
                $writer->save('php://output');
                break;
            default:
                echo "<pre>Nothing to do!</pre>";
                break;
        }
    }

    public function All()
    {
        \PhpOffice\PhpWord\Settings::setOutputEscapingEnabled(true);
        $np = $this->uri->segment(3);
        $nopol = urldecode($np);

        $this->load->model('simb_model');
        $simb = $this->simb_model->getJadwal($nopol);
        $isi = $this->simb_model->getDetail($nopol);
        //$now = date('d-m-Y');
        $bg = array('bgColor' => '66BBFF');

        $export = 'word';
        // $template = new TemplateProcessor(base_url().'assets/doc-templates/sppd-dep-baru.docx');
        $template = new TemplateProcessor(base_url() . '/assets/document-template/all.docx');
        $template->setValue('nopol', $nopol);
        $template->setValue('tgl_ck', $simb->date);
        $template->setValue('tgl_update', $simb->u_date);
        $template->setValue('simb_maber', $isi->simb_masa_berlaku);
        $template->setValue('simb_kondisi', $bg);
        $template->setValue('simb_dispensasi', $isi->simb_dispensasi);
        $template->setValue('simb_keterangan', $isi->simb_keterangan);
        $template->setValue('stm_maber', $isi->stm_kondisi);

        //$template->setValue('keterangan', $simb->simb_keterangan);
        // $template->setValue('berlaku_sampai_tanggal', '1');
        // $template->setValue('kondisi', '1');
        // $template->setValue('dispensasi', '2');
        // $template->setValue('lama_dispensasi', '3');
        // $template->setValue('keterangan', '4');

        $filename = 'ALL-' . $nopol . '.docx';

        switch ($export) {
            case 'word':
                header("Content-Description: File Transfer");
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
                header('Content-Transfer-Encoding: binary');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Expires: 0');
                $template->saveAs("php://output");
                break;
            case 'excel':
                // Redirect output to a client’s web browser (Xlsx)
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="' . $filename . '"');
                header('Cache-Control: max-age=0');
                // If you're serving to IE 9, then the following may be needed
                header('Cache-Control: max-age=1');
                // If you're serving to IE over SSL, then the following may be needed
                header('Expires: 0');
                header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
                header('Pragma: public'); // HTTP/1.0
                $writer = IOFactory::createWriter($template, 'Xlsx');
                $writer->save('php://output');
                break;
            default:
                echo "<pre>Nothing to do!</pre>";
                break;
        }
    }
}
