
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class History extends CI_Controller
{
    function index()
    {
        $daata['title'] = 'Checklist History';
        $daata['user'] = $this->db->get_where('a_user_account', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('user/v_history', $daata);
    }

    function fetch()
    {
        $output = '';
        $query = '';
        $this->load->model('m_search');
        if ($this->input->post('query')) {
            $query = $this->input->post('query');
        }
        $data = $this->m_search->fetch_data($query);
        $output .= '
         
                <table class="table table-bordered table-striped" style="align-text-center">
                <thead>
            <tr style="background-color: #F0CD13; color:black; text-align: center">
                <th>Police Number</th>
                <th>Checklist Date</th>
                <th>Print Checklist</th>
                <th>Checklist Updated</th>
                <th>Print Checklist Updated</th>
            </tr>
            </thead>
  ';
        if ($data->num_rows() > 0) {
            foreach ($data->result() as $row) {
                $output .= '
                <tbody>
                    <tr style="color:black; text-align: center">
                    <td>' . $row->nopol . '</td>
                    <td>' . $row->date . '</td>
                    <td>
                <a  class="btn btn-info btn-icon-split align-items-center" href="http://localhost/webpertamina_saya/download/Summary/'
                    . $row->nopol . '">
            <span class="icon text-white-40">
                <i class="fas fa-check"></i>
            </span>
            <span class="text" >Summary</span>
            </a>
            <a  class="btn btn-info btn-icon-split align-items-center" href="http://localhost/webpertamina_saya/download/All/'
                    . $row->nopol . '">
            <span class="icon text-white-40">
                <i class="fas fa-check"></i>
            </span>
            <span class="text" >All</span>
            </a>
        </td>
       <td>' . $row->u_date . '</td> ';
                $output .= '
                <td>
                <a  class="btn btn-info btn-icon-split align-items-center" href="#">
            <span class="icon text-white-20">
                <i class="fas fa-check"></i>
            </span>
            <span class="text" >Summary</span>
            </a>
            <a  class="btn btn-info btn-icon-split align-items-center" href="#">
            <span class="icon text-white-20">
                <i class="fas fa-check"></i>
            </span>
            <span class="text" >All</span>
            </a>
        </td>
        </tbody>
      </tr>
    ';
            }
        } else {
            $output .= '<tr>
       <td colspan="5">No Data Found</td>
      </tr>';
        }
        $output .= '</table>';
        echo $output;
    }

    public function unduhSummary()
    {
        \PhpOffice\PhpWord\Settings::setOutputEscapingEnabled(true);
        $id = 1;
        $this->load->model('simb_model');
        $simb = $this->simb_model->getDetail($id);

        $export = 'word';
        // $template = new TemplateProcessor(base_url().'assets/doc-templates/sppd-dep-baru.docx');
        $template = new TemplateProcessor(base_url() . '/assets/document-template/simb.docx');
        $template->setValue('maber', $simb->simb_masa_berlaku);
        $template->setValue('kondisi', $simb->simb_kondisi);
        $template->setValue('dispensasi', $simb->simb_dispensasi);
        $template->setValue('keterangan', $simb->simb_keterangan);
        // $template->setValue('berlaku_sampai_tanggal', '1');
        // $template->setValue('kondisi', '1');
        // $template->setValue('dispensasi', '2');
        // $template->setValue('lama_dispensasi', '3');
        // $template->setValue('keterangan', '4');

        $filename = date('Y_m_d') . '-summary.docx';

        switch ($export) {
            case 'word':
                header("Content-Description: File Transfer");
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
                header('Content-Transfer-Encoding: binary');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Expires: 0');
                $template->saveAs("php://output");
                break;
            case 'excel':
                // Redirect output to a client’s web browser (Xlsx)
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="' . $filename . '"');
                header('Cache-Control: max-age=0');
                // If you're serving to IE 9, then the following may be needed
                header('Cache-Control: max-age=1');
                // If you're serving to IE over SSL, then the following may be needed
                header('Expires: 0');
                header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
                header('Pragma: public'); // HTTP/1.0
                $writer = IOFactory::createWriter($template, 'Xlsx');
                $writer->save('php://output');
                break;
            default:
                echo "<pre>Nothing to do!</pre>";
                break;
        }
    }
}
