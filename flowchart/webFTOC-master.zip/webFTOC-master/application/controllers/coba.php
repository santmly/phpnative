<?php
defined('BASEPATH') or exit('No direct script access allowed');

class coba extends CI_Controller
{
    public function index()
    {
        $querySubMenu = " SELECT `a_user_account`
                            FROM table-name1 JOIN table-name2 
                                ON column-name1 = column-name2
                            WHERE condition";
    }
}
