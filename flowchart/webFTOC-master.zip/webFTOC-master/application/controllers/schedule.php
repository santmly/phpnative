<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class schedule extends CI_Controller
{

    public function index($year = null, $month = null)
    {
        if (!$year) {
            $year = date('Y');
        }
        if (!$month) {
            $month = date('m');
        }
        $day = $this->input->post('day');

        if (strlen($day) == 13) {
            $day = substr($day, 0, 2);
        }

        $this->load->model('calendar_model');
        if ($day) {
            $this->calendar_model->update_calendar_data(
                $this->input->post('data'),
                "$year-$month-$day"
            );
        }

        $data['title'] = 'Make a Schedule';
        $data['calendar'] = $this->calendar_model->generate($year, $month);
        $data['user'] = $this->db->get_where('a_user_account', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('user/v_schedule', $data);
    }
}
