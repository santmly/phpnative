<?php
defined('BASEPATH') or exit('No direct script access allowed');

class qq2 extends CI_Controller
{
    public function approve()
    {
        $nopol = $this->uri->segment(3);
        $nopol = urldecode($nopol);
        $this->db->select('nopol, qq_acc')->from('jadwal');
        $where = array(
            'nopol' => $nopol
        );
        $this->db->where($where);
        $this->db->update('jadwal', array(
            'qq_acc' => 0
        ));
        redirect('approving');
    }
    public function notapprove()
    {
        $nopol = $this->uri->segment(3);
        $nopol = urldecode($nopol);
        $this->db->select('nopol, qq_acc')->from('jadwal');
        $where = array(
            'nopol' => $nopol
        );
        $this->db->where($where);
        $this->db->update('jadwal', array(
            'qq_acc' => 1
        ));
        redirect('approving');
    }
}
