<nav style="background-color: #F0CD13; font-weight:bold; color:black;" class="navbar navbar-expand topbar mb-4">
    <h1 class="h2 mb-0 text-gray-900 mx-auto"> FUEL TERMINAL ONLINE CHECKLIST</h1>
</nav>