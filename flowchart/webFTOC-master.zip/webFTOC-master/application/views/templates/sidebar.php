<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('user/') ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-truck-moving"></i>
        </div>
        <div class="sidebar-brand-text mx-3">FTOC PANEL</div>
    </a>

    <hr class="sidebar-divider my-0">

    <div class="sidebar-heading ptb-8">
        <?= $user['user_role'] ?>
    </div>

    <?php
    $userId = $user['user_role'];
    $querySubMenu = "SELECT * FROM `a_sub_menu`
                    WHERE `menu_id` = '$userId'
    ";
    $SubMenu = $this->db->query($querySubMenu)->result_array();
    ?>

    <?php foreach ($SubMenu as $sm) : ?>

        <li class="nav-item">
            <a class="nav-link ptb-8" href="<?= base_url($sm['url']); ?>">
                <i class="<?php echo $sm['icon'] ?>"></i>
                <span><?php echo $sm['title'] ?></span></a>
        </li>

    <?php endforeach ?>

    <div class="ptb-8"> </div>


    <hr class="sidebar-divider my-0 ">

    <div class="sidebar-heading ptb-8">
        ACCOUNT
    </div>
    <!-- Nav Item - Schedule -->
    <li class="nav-item">
        <a class="nav-link ptb-8" href="<?= base_url('myprofile/'); ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>My Profile</span></a>
    </li>
    <!-- Divider -->
    <!-- Nav Item - Logout -->
    <li class="nav-item ">
        <a class="nav-link ptb-8" href="<?= base_url('auth/logout') ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout

            </span></a>
    </li>
    <div class="ptb-8"> </div>

    <hr class="sidebar-divider">
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>


</ul>