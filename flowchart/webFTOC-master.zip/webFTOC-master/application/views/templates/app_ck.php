<li class="nav-item">
    <a class="nav-link ptb-8 collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-file-contract"></i>
        <span>Approving Checklist</span>
    </a>
    <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Supervisor :</h6>
            <a class="collapse-item" href="utilities-color.html">HSSE</a>
            <a class="collapse-item" href="<?= base_url('qq/') ?>">QQ</a>
            <a class="collapse-item" href="utilities-animation.html">Distribusi</a>
        </div>
    </div>
    <div class="ptb-8"> </div>

</li>