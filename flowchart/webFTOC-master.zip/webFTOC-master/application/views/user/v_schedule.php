<?php $this->load->view('templates/header') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php $this->load->view('templates/sidebar') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <style type="text/css">
                    .calendar {
                        font-family: Arial;
                        font-size: 12px;
                    }

                    table.calendar {
                        margin: auto;
                        border-collapse: collapse;
                    }

                    .calendar .days td {
                        width: 80px;
                        height: 80px;
                        padding: 4px;
                        border: 1px solid #999;
                        vertical-align: top;
                        background-color: #DEF;

                    }

                    .calendar .days td:hover {
                        background-color: #FFF;
                    }

                    .calendar .highlight {
                        font-weight: bold;
                        color: #00F;
                    }
                </style>

                <!-- Topbar -->
                <nav style="background-color: #F0CD13; font-weight:bold; color:black;" class="navbar navbar-expand topbar mb-4">
                    <h1 class="h2 mb-0 text-black mx-auto"> FUEL TERMINAL ONLINE CHECKLIST</h1>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 style="text-align: center; color:black;" class="h3 mb-4">Make a Schedule</h1>

                </div>
                <!-- /.container-fluid -->
                <div class="container-fluid">
                    <?= $calendar; ?>
                </div>
            </div>
            <!-- End of Main Content -->
            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; by AppSolut 2019</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.calendar .day').click(function() {
                day_num = $(this).find('.day_num').html();
                //days = strip_tags(day_num);
                // alert(day_num);

                day_data = prompt('masukkan nomor plat');
                if (day_data != null) {
                    $.ajax({
                        url: window.location,
                        type: 'POST',
                        data: {
                            day: day_num,
                            data: day_data
                        },
                        success: function(msg) {
                            location.reload();
                        }

                    });
                }
            });
        });
    </script>
    <?php $this->load->view('templates/script_footer') ?>