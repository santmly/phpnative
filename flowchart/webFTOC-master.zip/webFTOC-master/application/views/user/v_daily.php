<?php $this->load->view('templates/header') ?>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Start Sidebar -->

        <?php $this->load->view('templates/sidebar') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <!-- Topbar -->
            <?php $this->load->view('templates/topbar') ?>
            <!-- End of Topbar -->
            <!-- Begin Page Content -->
            <div class="container-fluid">
                <nav style="background-color: #08CDF8; font-weight:bold; color:black;" class="navbar navbar-expand topbar mb-2">
                    <h1 class="h3 mb-0 text-black mx-auto">Daily Checklist</h1>
                </nav>
            </div>
            <div class="container-fluid">

                <table class="table table-bordered table-striped" style="text-align: center">
                    <thead>
                        <tr style="text-align: center ">
                            <th style="background-color: #FFCC25; color:black">Police Number</th>
                            <th style="background-color: #FFCC25;  color:black">Checklist Date</th>
                            <th style="background-color: #FFCC25; color:black">Percentage (%)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--Fetch data dari database-->
                        <?php foreach ($isitabel->result() as $row) : ?>
                            <tr style="text-align: center; color:black">
                                <td><?php echo $row->nopol; ?></td>
                                <td><?php echo $row->date; ?></td>
                                <td><?php echo $row->presentase; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>
            <!-- End of Main Content -->
            <!-- Footer -->
            <?php $this->load->view('templates/footer') ?>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <?php $this->load->view('templates/script_footer') ?>