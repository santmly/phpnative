<?php $this->load->view('templates/header') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php $this->load->view('templates/sidebar') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php $this->load->view('templates/topbar') ?>

                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <nav style="background-color: #08CDF8; font-weight:bold; color:black;" class="navbar navbar-expand topbar mb-2">
                        <h1 class="h3 mb-0 text-black mx-auto">Checklist History</h1>
                    </nav>
                </div>

                <div class=" container-fluid">
                    <div class="d-sm-inline-block form-inline mx-2 my-1 my-md-2 mw-120 navbar-search">

                        <div class="input-group">
                            <button class=" margin-left: auto; btn btn-primary" type="button">
                                <i class="fas fa-fw fa-search fa-sm"></i>
                            </button>
                            <input type="text" name="search_text" style="font-size:17px" id="search_text" placeholder="Search by Police Number" class="form-control" />
                            <form>
                                <div class="form-group">
                                    <span style="display:inline-block; width: 100px;"></span>
                                    <label style="color:black; font-size: 18px; width: 60px">Month:</label>
                                    <select class="form-control" name="category" id="category" required>
                                        <option value="">No Selected</option>
                                        <option value="">1</option>
                                        <option value="">2</option>
                                        <option value="">3</option>
                                        <option value="">4</option>
                                        <option value="">5</option>
                                        <option value="">6</option>
                                        <option value="">7</option>
                                        <option value="">8</option>
                                        <option value="">9</option>
                                        <option value="">10</option>
                                        <option value="">11</option>
                                        <option value="">12</option>

                                    </select>
                                    <span style="display:inline-block; width: 100px;"></span>
                                    <label style="color:black; font-size: 18px;  width: 50px">Year:</label>

                                    <select class="form-control" id="sub_category" name="sub_category" required>
                                        <span style="display:inline-block; width: 100x; "></span>
                                        <option>No Selected</option>
                                        <option>2019</option>
                                        <option>2020</option>
                                        <option>2021</option>
                                        <option>2022</option>
                                        <option>2023</option>

                                    </select>
                                </div>
                            </form>
                        </div>

                    </div>
                    <h1 class="mb-4">
                    </h1>
                    <div id="result">
                    </div>
                </div>
                <div style="clear:both">
                </div>
                <script>
                    $(document).ready(function() {

                        load_data();

                        function load_data(query) {
                            $.ajax({
                                url: "<?php echo base_url(); ?>history/fetch",
                                method: "POST",
                                data: {
                                    query: query
                                },
                                success: function(data) {
                                    $('#result').html(data);
                                }
                            })
                        }

                        $('#search_text').keyup(function() {
                            var search = $(this).val();
                            if (search != '') {
                                load_data(search);
                            } else {
                                load_data();
                            }
                        });
                    });
                </script>
            </div>
            <?php $this->load->view('templates/footer') ?>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
</body>

<?php $this->load->view('templates/script_footer') ?>