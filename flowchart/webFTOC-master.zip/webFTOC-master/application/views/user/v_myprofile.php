<?php $this->load->view('templates/header') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php $this->load->view('templates/sidebar') ?>
        <!-- End of Sidebar -->
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <?php $this->load->view('templates/topbar') ?>
                <!-- End of Topbar -->
                <div class="container-fluid">
                    <nav style="background-color: #08CDF8; font-weight:bold; color:black;" class="navbar navbar-expand topbar mb-2">
                        <h1 class="h3 mb-0 text-black mx-auto">My Profile</h1>
                    </nav>
                </div>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->

                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row no-gutters">
                            <div class="col-md-4">
                                <img src="<?= base_url('assets/img/profile/pertamina.png') ?>" class="card-img" alt="...">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h1 style="color:black" class="card-title"><?= $user['username'] ?></h1>
                                    <p style="color:black" class="card-text"><?= $user['email'] ?></p>
                                    <p style="color:black" class="card-text"><?= $user['user_role'] ?></p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php $this->load->view('templates/footer') ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php $this->load->view('templates/script_footer') ?>