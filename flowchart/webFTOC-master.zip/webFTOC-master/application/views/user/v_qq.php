<?php $this->load->view("templates/header") ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php $this->load->view('templates/sidebar') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <!-- Topbar -->
            <?php $this->load->view('templates/topbar') ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <h1 style="text-align: center; color:black" class="h3 mb-4 mx-auto">Approving Checklist: QQ</h1>

            <div class="container-fluid">

                <table class="table table-bordered table-striped" style="text-align: center">
                    <thead>
                        <tr>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Police Number</th>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Checklist Date</th>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Checklist Updated</th>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Percentage (%)</th>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--Fetch data dari database-->

                        <?php foreach ($isitabel->result() as $row) : ?>
                            <tr style=" text-align: center; ">
                                <td style=" color:black; text-align: center; "><?php echo $row->nopol; ?></td>
                                <td style=" color:black; text-align: center; "><?php echo $row->date; ?></td>
                                <td style=" color:black; text-align: center; "><?php echo $row->u_date; ?></td>
                                <td style="color:black;"><?php echo $row->presentase; ?></td>
                                <td>
                                    <?php if ($row->qq_acc == '1') { ?>
                                        <a href=" <?php echo site_url('qq2/approve') . '/' . $row->nopol; ?>" class="btn btn-info btn-icon-split">

                                            <span class="icon  text-white-20">
                                                <i class="fas fa-check"></i>
                                            </span>
                                            <span class="text">Approved</span>
                                        </a>
                                    <?php } else if ($row->qq_acc == '0') { ?>
                                        <a href="<?php echo site_url('qq2/notapprove') . '/' . $row->nopol; ?>" class="btn btn-danger btn-icon-split">
                                            <span class="icon btn-icon-split text-white-20">
                                                <i class="fas fa-fw align-item-center fa-exclamation-triangle"></i>
                                            </span>
                                            <span class="text">Not Approved</span>
                                        </a>
                                    <?php } ?>
                                </td>

                            </tr>
                        <?php endforeach; ?>

                    </tbody>
                </table>

            </div>
            <!-- /.container-fluid -->

            <!-- End of Main Content -->

            <!-- Footer -->
            <?php $this->load->view('templates/footer') ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



    <?php $this->load->view('templates/script_footer') ?>