<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?= $title; ?></title>

    <!-- Custom fonts for this template-->
    <link href="<?= base_url('assets/') ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>css/style.css">

    <!-- Custom styles for this template-->
    <link href="<?= base_url('assets/') ?>css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('user/') ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-truck-moving"></i>
                </div>
                <div class="sidebar-brand-text mx-3">FTOC PANEL</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">
            <!-- Heading -->
            <div class="sidebar-heading pb-24">
                Administrator
            </div>
            <!-- Nav Item - Schedule -->
            <li class="nav-item">
                <a class="nav-link ptb-8" href="<?= base_url('schedule/') ?>">
                    <i class="far fa-fw fa-calendar-alt"></i>
                    <span>Make a Schedule</span></a>
            </li>
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link ptb-8 collapsed" href="<?= base_url('daily/') ?>">
                    <i class="fas fa-fw fa-calendar-day"></i>
                    <span>Daily Checklist</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link ptb-8 collapsed" href="<?= base_url('history/') ?>">
                    <i class="fas fa-fw fa-tasks"></i>
                    <span>Checklist History</span>
                </a>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link ptb-08 collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-file-contract"></i>
                    <span>Approving Checklist</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Supervisor :</h6>
                        <a class="collapse-item" href="utilities-color.html">HSSE</a>
                        <a class="collapse-item" href="<?= base_url('qq/') ?>">QQ</a>
                        <a class="collapse-item" href="utilities-animation.html">Distributor</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">
            <!-- Heading -->
            <div class="sidebar-heading pb-24">
                Users
            </div>
            <!-- Nav Item - Schedule -->
            <li class="nav-item">
                <a class="nav-link ptb-416">
                    <i class="fas fa-fw fa-user"></i>
                    <span>My Profile</span></a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Schedule -->
            <li class="nav-item">
                <a class="nav-link ptb-416" href="<?= base_url('auth/logout') ?>">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider pb-32">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->


            <!-- Topbar -->
            <nav style="background-color: #F0CD13; font-weight:bold; color:black;" class="navbar navbar-expand topbar mb-4">
                <h1 class="h2 mb-0 text-black mx-auto"> FUEL TERMINAL ONLINE CHECKLIST</h1>
            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <h1 style="text-align: center; color:black" class="h3 mb-4 mx-auto">Approving Checklist: QQ</h1>

            <div class="container-fluid">

                <table class="table table-bordered table-striped" style="text-align: center">
                    <thead>
                        <tr>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Police Number</th>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Checklist Date</th>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Checklist Updated</th>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Percentage (%)</th>
                            <th style="background-color:#73BA25; color:black; text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--Fetch data dari database-->

                        <?php foreach ($isitabel->result() as $row) : ?>
                            <tr style=" text-align: center; ">
                                <td style=" color:black; text-align: center; "><?php echo $row->nopol; ?></td>
                                <td style=" color:black; text-align: center; "><?php echo $row->date; ?></td>
                                <td style=" color:black; text-align: center; "><?php echo $row->u_date; ?></td>
                                <td style="color:black;"><?php echo $row->presentase; ?></td>
                                <td>
                                    <?php if ($row->qq_acc == '1') { ?>
                                        <a href=" <?php echo site_url('qq2/approve') . '/' . $row->nopol; ?>" class="btn btn-info btn-icon-split">

                                            <span class="icon  text-white-20">
                                                <i class="fas fa-check"></i>
                                            </span>
                                            <span class="text">Approved</span>
                                        </a>
                                    <?php } else if ($row->qq_acc == '0') { ?>
                                        <a href="<?php echo site_url('qq2/notapprove') . '/' . $row->nopol; ?>" class="btn btn-danger btn-icon-split">
                                            <span class="icon btn-icon-split text-white-20">
                                                <i class="fas fa-fw align-item-center fa-exclamation-triangle"></i>
                                            </span>
                                            <span class="text">Not Approved</span>
                                        </a>
                                    <?php } ?>
                                </td>

                            </tr>
                        <?php endforeach; ?>

                    </tbody>
                </table>

            </div>


            <!-- Page Heading -->

            <!-- /.container-fluid -->

            <!-- End of Main Content -->

            <!-- Footer -->

            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; by AppSolut 2019</span>
                    </div>
                </div>

            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?= base_url('auth/logout') ?>">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?= base_url('assets/') ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/') ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?= base_url('assets/') ?>vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?= base_url('assets/') ?>js/sb-admin-2.min.js"></script>

</body>

</html>