<?php
class m_app extends CI_Model
{
    public function index()
    {
        $query = $this->db->query('SELECT * FROM qq_checklist');

        $row = $query->row_array();
        if ($row['aksi'] == '0') {
            $data['aksi'] = '1';
            $where['id'] = $row['id'];
            $this->db->where($where);
            $this->db->update('qq_checklist', $data);
        }
    }
}
