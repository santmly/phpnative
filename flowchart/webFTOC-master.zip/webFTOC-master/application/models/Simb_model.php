<?php defined('BASEPATH') or exit('No direct script access allowed');

class Simb_model extends CI_Model
{

    private $table = 'daftartruk';
    private $tablejadwal = 'jadwal';

    public function getAll()
    {
        return $this->db->select()
            ->from($this->table)
            ->get()
            ->result();
    }

    public function getDetail($id)
    {
        $query = $this->db->select()
            ->from($this->table)
            ->where('id', $id)
            ->get()
            ->row();
        return $query;
    }

    public function getJadwal($id)
    {
        $query = $this->db->select()
            ->from($this->tablejadwal)
            ->where('nopol', $id)
            ->get()
            ->row();
        return $query;
    }
}
