<?php
class calendar_model extends CI_Model
{
    public function read_calendar_data($year, $month)
    {
        $this->db->like('date', "$year-$month", 'after');
        $query = $this->db->get('jadwal');

        $cal_data = array();

        $results = $query->result_array();

        foreach ($results as $event) {
            $day = ltrim(substr($event['date'], 8, 2), '0');
            if (array_key_exists($day, $cal_data)) {

                $cal_data[$day] =  '</ul></li>' . $cal_data[$day] . '</li><li>' . $event["nopol"] . '</li></ul>';
            } else {

                $cal_data[$day] = '</li></ul>' . '</li><li>'  . $event["nopol"] . '</li></ul>';
            }
        }
        return $cal_data;
    }

    public function update_calendar_data($nopol, $date)
    {
        $this->db->select('nopol, date')->from('jadwal');
        $where = array(
            'nopol' => $nopol
        );
        $this->db->where($where);
        $this->db->update('jadwal', array(
            'date' => $date
        ));
    }
    function generate($year = null, $month = null)
    {
        $prefs = array(
            'start_day' => 'monday',
            'show_next_prev' => true,
            'next_prev_url' => base_url() . 'schedule/index'
        );


        $prefs['template'] = '

        {table_open}<div class="container-fluid"><table class="table table-bordered calendar table-striped">{/table_open}
        {heading_row_start}<tr style="text-align: center;  background-color: #0E88D3; font-weight:bold; font-size: 30px; color:black; align:center;">{/heading_row_start}

        {heading_previous_cell}<th><a style="color: black" href="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
        {heading_title_cell}<th colspan="{colspan}">{heading}</th>{/heading_title_cell}
        {heading_next_cell}<th><a style="color: black" href="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}

        {heading_row_end}</tr>{/heading_row_end}

        {week_row_start}<tr style="text-align: center; background-color: #F0CD13; font-size: 25px; color:black;">{/week_row_start}
        {week_day_cell}<td>{week_day}</td>{/week_day_cell}
        {week_row_end}</tr>{/week_row_end}

        {cal_row_start}<tr style= " font-size: 18px; color:black;"; class="days">{/cal_row_start}
        {cal_cell_start}<td class="day">{/cal_cell_start}
        {cal_cell_start_today}<td class="day">{/cal_cell_start_today}
        {cal_cell_start_other}<td class="other-month">{/cal_cell_start_other}
        
        {cal_cell_content}
            <div style="font-size: 15px; color:black;" class="day_num">{day}<div>
            <div class="content">{content}<div>      
        {/cal_cell_content}

        {cal_cell_content_today}
            <div class="day_num highlight">{day}<div>
            <div class="content">{content}<div>
        {/cal_cell_content_today}

        {cal_cell_no_content}<div class="day_num">{day}<div>{/cal_cell_no_content}
        {cal_cell_no_content_today}<div class="day_num highlight">{day}<div>{/cal_cell_no_content_today}

        {cal_cell_blank}&nbsp;{/cal_cell_blank}

        {cal_cell_other}{day}{/cal_cel_other}

        {cal_cell_end}</td>{/cal_cell_end}
        {cal_cell_end_today}</td>{/cal_cell_end_today}
        {cal_cell_end_other}</td>{/cal_cell_end_other}
        {cal_row_end}</tr>{/cal_row_end}

        {table_close}</table>{/table_close}
';

        $this->load->library('calendar', $prefs);
        //$this->update_calendar_data('B 9502 TEI', '2019-10-20');
        $cal_data = $this->read_calendar_data($year, $month);
        return $this->calendar->generate($year, $month, $cal_data);
    }
}
