<?php
class m_daily extends CI_Model
{
    public function getPresen()
    {
        $query = $this->db->query('SELECT * FROM daftartruk');
        $result = $query->row_array();

        $resultf = $this->db->list_fields('daftartruk');
        foreach ($resultf as $field) {
            $data[] = $field;
        }
        $temp = 0;


        for ($i = 0; $i < 11; $i++) {
            if ($result[$data[$i]] == '0') {
                $temp++;
            }
        }
        $n = (100 - ($temp / 3) * 100);
        $n = round($n, 2);


        $this->update($n, 'AB 8641 NE');
    }

    public function update($nilai, $nopol)
    {
        $this->db->select('nopol, presentase')->from('jadwal');
        $where = array(
            'nopol' => $nopol
        );
        $this->db->where($where);
        $this->db->update('jadwal', array(
            'presentase' => $nilai
        ));
    }
    public function generate()
    {
        $this->load->library('table');
        $query = $this->db->select('nopol, date, presentase')->from('jadwal')->get();

        //UPDATE
        $dataa = array('data1', 'data2', 'data3', 'data4');

        $n = 0;
        foreach ($query->result() as $row) {
            $dataa[$n] = array(
                $row->nopol,
                $row->date,
                $row->presentase
            );
            $n = $n + 1;
        }
        $this->table->set_heading(array('No. Polisi', 'Tanggal Checklist', 'Presentase'));
        for ($i = 0; $i < 4; $i++) {
            $this->table->add_row($dataa[$i]);
            // $query = $this->db->query('SELECT * FROM jadwal');
        }
        $this->getPresen();
        //return $this->table->generate();
    }
}
