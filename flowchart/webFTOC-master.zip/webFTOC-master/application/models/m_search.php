<?php
class m_search extends CI_Model
{
    function fetch_data($query)
    {
        $this->db->select("*");
        $this->db->from("jadwal");
        if ($query != '') {
            $this->db->like('nopol', $query);
        }
        $this->db->order_by('id', 'ASC');
        return $this->db->get();
    }
}
