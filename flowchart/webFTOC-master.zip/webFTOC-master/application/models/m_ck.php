<?php defined('BASEPATH') or exit('No direct script access allowed');

class m_ck extends CI_Model
{

    private $table = 'daftartruk';

    public function getAll()
    {
        return $this->db->select()
            ->from($this->table)
            ->get()
            ->result();
    }

    public function getDetail($id)
    {
        $query = $this->db->select()
            ->from($this->table)
            ->where('id', $id)
            ->get()
            ->row();
        return $query;
    }
}
