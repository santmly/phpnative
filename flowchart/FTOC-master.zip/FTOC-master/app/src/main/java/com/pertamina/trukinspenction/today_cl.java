package com.pertamina.trukinspenction;


import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class today_cl extends AppCompatActivity implements DatePickerDialog.OnDateSetListener{
    private TextView setDate1, setDate2,nopolcl;
    private static final String TAG = "today_cl";
    private CheckBox Kondisi1,Kondisi2,Kondisi3,Kondisi4,Kondisi5,Kondisi6;
    private CheckBox Kondisi7,Kondisi8,Kondisi9,Kondisi10,Kondisi11;
    private EditText setKet1,setKet2,setKet3,setKet4,setKet5,setKet6;
    private EditText setKet7,setKet8,setKet9,setKet10,setKet11,etDispen2,etDispen3;
    private Spinner dd1,dd2,dd3,dd4,dd5,dd6,dd7,dd8,dd9,dd10,dd11;
    public Integer state = 0;
    private String idnopol;
    private Button bt1;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.today_cl);
        nopolcl = (TextView) findViewById(R.id.nopol_cl);
        Intent i = getIntent();
        String nopolhasil = i.getStringExtra("dataku");
        nopolcl.setText(nopolhasil);

        setDate1 = (TextView) findViewById(R.id.date1);
        setDate2 = (TextView) findViewById(R.id.date2);
        setDate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDate();
                state = 1;
            }
        });
        setDate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDate();
                state = 2;
            }
        });
        this.initializeViews();  jenissp();  this.handleClickEvents();


    }

    private void showDate () {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();

    }


    @Override
    public void onDateSet (DatePicker view,int year, int month, int dayOfMonth){
        month = month + 1;
        String date = year + "-" + month + "-" + dayOfMonth;
        if(state == 1){
        setDate1.setText(date); state = 0;}
        else if(state == 2){
            setDate2.setText(date);
            state = 0;
        }
    }

    public void jenissp()
    {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item);

        adapter.add("-");adapter.add("1"); adapter.add("2"); adapter.add("3"); adapter.add("5"); adapter.add("6"); adapter.add("7");
        adapter.add("10"); adapter.add("15"); adapter.add("30");

        dd1.setAdapter(adapter); dd1.setSelection(0);
        dd2.setAdapter(adapter); dd2.setSelection(0);
        dd3.setAdapter(adapter); dd3.setSelection(0);
        dd4.setAdapter(adapter); dd4.setSelection(0);
        dd5.setAdapter(adapter); dd5.setSelection(0);
        dd6.setAdapter(adapter); dd6.setSelection(0);
        dd7.setAdapter(adapter); dd7.setSelection(0);
        dd8.setAdapter(adapter); dd8.setSelection(0);
        dd9.setAdapter(adapter); dd9.setSelection(0);
        dd10.setAdapter(adapter); dd10.setSelection(0);
        dd11.setAdapter(adapter); dd11.setSelection(0);

    }
    private void initializeViews()
    {
        Kondisi1 = (CheckBox) findViewById(R.id.cbBaik1);  setKet1 = (EditText) findViewById(R.id.etKet1);
        Kondisi2 = (CheckBox) findViewById(R.id.cbBaik2);  setKet2 = (EditText) findViewById(R.id.etKet2);
        Kondisi3 = (CheckBox) findViewById(R.id.cbBaik3);  setKet3 = (EditText) findViewById(R.id.etKet3);
        Kondisi4 = (CheckBox) findViewById(R.id.cbBaik4);  setKet4 = (EditText) findViewById(R.id.etKet4);
        Kondisi5 = (CheckBox) findViewById(R.id.cbBaik5);  setKet5 = (EditText) findViewById(R.id.etKet5);
        Kondisi6 = (CheckBox) findViewById(R.id.cbBaik6);  setKet6 = (EditText) findViewById(R.id.etKet6);
        Kondisi7 = (CheckBox) findViewById(R.id.cbBaik7);  setKet7 = (EditText) findViewById(R.id.etKet7);
        Kondisi8 = (CheckBox) findViewById(R.id.cbBaik8);  setKet8 = (EditText) findViewById(R.id.etKet8);
        Kondisi9 = (CheckBox) findViewById(R.id.cbBaik9);  setKet9 = (EditText) findViewById(R.id.etKet9);
        Kondisi10 = (CheckBox) findViewById(R.id.cbBaik10);  setKet10 = (EditText) findViewById(R.id.etKet10);
        Kondisi11 = (CheckBox) findViewById(R.id.cbBaik11); setKet11 = (EditText) findViewById(R.id.etKet11);

        dd1 = (Spinner) findViewById(R.id.sp1);  dd2 = (Spinner) findViewById(R.id.sp2);  dd3 = (Spinner) findViewById(R.id.sp3);   dd4 = (Spinner) findViewById(R.id.sp4);
        dd5 = (Spinner) findViewById(R.id.sp5);  dd6 = (Spinner) findViewById(R.id.sp6);  dd7 = (Spinner) findViewById(R.id.sp7);  dd8 = (Spinner) findViewById(R.id.sp8);
        dd9 = (Spinner) findViewById(R.id.sp9);  dd10 = (Spinner) findViewById(R.id.sp10);  dd11 = (Spinner) findViewById(R.id.sp11);

        bt1 = (Button) findViewById(R.id.button2);
    }
    private void handleClickEvents()
    {
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String SIMB = setDate1.getText().toString(); String STM = setDate2.getText().toString();
                Boolean Kon1 = Kondisi1.isChecked(); Boolean Kon2 = Kondisi2.isChecked(); Boolean Kon3 = Kondisi3.isChecked(); Boolean Kon4 = Kondisi4.isChecked();
                Boolean Kon5 = Kondisi5.isChecked(); Boolean Kon6 = Kondisi6.isChecked(); Boolean Kon7 = Kondisi7.isChecked(); Boolean Kon8 = Kondisi8.isChecked();
                Boolean Kon9 = Kondisi9.isChecked(); Boolean Kon10 = Kondisi10.isChecked(); Boolean Kon11 = Kondisi11.isChecked();

                String Ket1 = setKet1.getText().toString(); String Ket5 = setKet5.getText().toString(); String Ket9 = setKet9.getText().toString();
                String Ket2 = setKet2.getText().toString(); String Ket6 = setKet6.getText().toString(); String Ket10 = setKet10.getText().toString();
                String Ket3 = setKet3.getText().toString(); String Ket7 = setKet7.getText().toString(); String Ket11 = setKet11.getText().toString();
                String Ket4 = setKet4.getText().toString(); String Ket8 = setKet8.getText().toString();

                String hdd1 = dd1.getSelectedItem().toString(); String hdd4 = dd4.getSelectedItem().toString();
                String hdd2 = dd2.getSelectedItem().toString(); String hdd5 = dd5.getSelectedItem().toString();
                String hdd3 = dd3.getSelectedItem().toString(); String hdd6 = dd6.getSelectedItem().toString();
                String hdd7 = dd7.getSelectedItem().toString(); String hdd9 = dd9.getSelectedItem().toString();
                String hdd8 = dd8.getSelectedItem().toString(); String hdd10 = dd10.getSelectedItem().toString();
                String hdd11 = dd11.getSelectedItem().toString();

                idnopol = nopolcl.getText().toString();

                initialVar s = new initialVar();

                s.setSIMB1(SIMB); s.setSTM(STM);
                s.setKeterangan1(Ket1); s.setKeterangan2(Ket2); s.setKeterangan3(Ket3); s.setKeterangan4(Ket4);
                s.setKeterangan5(Ket5); s.setKeterangan6(Ket6); s.setKeterangan7(Ket7); s.setKeterangan8(Ket8);
                s.setKeterangan9(Ket9); s.setKeterangan10(Ket10); s.setKeterangan11(Ket11);

                s.setDispen1(hdd1); s.setDispen2(hdd2); s.setDispen3(hdd3); s.setDispen1(hdd4); s.setDispen2(hdd5); s.setDispen3(hdd6);
                s.setDispen7(hdd7); s.setDispen8(hdd8); s.setDispen9(hdd9); s.setDispen10(hdd10); s.setDispen11(hdd11);

                s.setKondisi1(Kon1 ? 1 : 0); s.setKondisi2(Kon2 ? 1 : 0); s.setKondisi3(Kon3 ? 1 : 0); s.setKondisi4(Kon4 ? 1 : 0);
                s.setKondisi5(Kon5 ? 1 : 0); s.setKondisi6(Kon6 ? 1 : 0); s.setKondisi7(Kon7 ? 1 : 0); s.setKondisi8(Kon8 ? 1 : 0);
                s.setKondisi9(Kon9 ? 1 : 0); s.setKondisi10(Kon10 ? 1 : 0); s.setKondisi11(Kon11 ? 1 : 0);


                new withMySQL(today_cl.this).add(s,idnopol,setDate1,setKet1,dd1,setDate2,dd2,setKet2,etDispen3,dd3);

            }
        });
    }

}
