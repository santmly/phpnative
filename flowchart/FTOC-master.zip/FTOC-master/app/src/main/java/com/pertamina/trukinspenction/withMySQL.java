package com.pertamina.trukinspenction;

import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.google.gson.JsonIOException;

import org.json.JSONArray;
import org.json.JSONException;

public class withMySQL {
    private static final String Data_Insert_URL = "http://192.168.43.254/pertamina/update.php";
    private final Context c;

    public withMySQL(Context c) {
        this.c = c;
    }

    public void add(final initialVar i, String idne, final View...inputViews)
    {
        if(i==null)
        {
            Toast.makeText(c, "No Data To Save", Toast.LENGTH_SHORT).show();
        }
        else
        {
            AndroidNetworking.post(Data_Insert_URL)
                    .addBodyParameter("id",idne)
                    .addBodyParameter("SIM_B",i.getSIMB1()).addBodyParameter("Kondisi1",String.valueOf(i.getKondisi1())).addBodyParameter("Dispen1",i.getDispen1()) .addBodyParameter("Keterangan1",i.getKeterangan1())
                    .addBodyParameter("STM",i.getSTM()).addBodyParameter("Kondisi2",String.valueOf(i.getKondisi2())) .addBodyParameter("Dispen2",i.getDispen2()) .addBodyParameter("Keterangan2",i.getKeterangan2())
                    .addBodyParameter("Kondisi3",String.valueOf(i.getKondisi3())) .addBodyParameter("Dispen3",i.getDispen3()) .addBodyParameter("Keterangan3",i.getKeterangan3())
                    .setTag("TAG_ADD")
                    .build()
                    .getAsJSONArray(new JSONArrayRequestListener() {
                        @Override
                        public void onResponse(JSONArray response)
                        {
                            if (response != null) {
                                try {
                                        String responseString = response.toString();
                                        Toast.makeText(c,"PHP SERVER RESPONSE : "+responseString, Toast.LENGTH_SHORT).show();

                                        if (responseString.equalsIgnoreCase("Success")) {
                                                      }
                                    } catch (JsonIOException e)
                                        {
                                            e.printStackTrace();
                                            Toast.makeText(c, "GOOD RESPONSE BUT JAVA CAN'T PARSE JSON IT RECEIVED : "+e.getMessage(),Toast.LENGTH_SHORT).show();
                                        }
                            }
                        }

                        @Override
                        public void onError(ANError anError)
                        {
                            //Toast.makeText(c, "UNSUCCESSFUL : ERROR IS : "+anError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }
}
