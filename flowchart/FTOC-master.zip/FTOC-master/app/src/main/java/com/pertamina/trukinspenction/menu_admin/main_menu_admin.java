package com.pertamina.trukinspenction.menu_admin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.pertamina.trukinspenction.R;

public class main_menu_admin extends Activity{

    private Button btRekap;
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        btRekap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goRekap();
            }

        }); }

    private void goRekap() {
        Intent intent = new Intent(main_menu_admin.this,hasil_qq.class);
        startActivity(intent);
    }


}
