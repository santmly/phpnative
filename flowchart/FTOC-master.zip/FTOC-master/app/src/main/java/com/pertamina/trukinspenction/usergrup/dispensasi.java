package com.pertamina.trukinspenction.usergrup;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.gson.JsonArray;
import com.google.gson.JsonIOException;
import com.pertamina.trukinspenction.R;
import com.pertamina.trukinspenction.ambiljenis_disp;
import com.pertamina.trukinspenction.fixDispensasi;
import com.pertamina.trukinspenction.initialVar;
import com.pertamina.trukinspenction.mt_dispensasi;
import com.pertamina.trukinspenction.today_cl;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class dispensasi extends AppCompatActivity {
        private RequestQueue rq;
        private int temp, panjang;
        private String [] TV;
        private LinearLayout linearMAIN;
        private static TextView tvnopoldisp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dispensasi);
        Button btTampildis;
        rq = Volley.newRequestQueue(this);
        linearMAIN = (LinearLayout) findViewById(R.id.linear);
        tvnopoldisp = (TextView) findViewById(R.id.nopoldisp);
        Intent i = getIntent();
        String data = i.getStringExtra("dataku");
        tvnopoldisp.setText(data);
        getjenis_disp(nopolnya());
    }

    private void print()
    {
        for (int i = 0; i < panjang; i++) {
            LinearLayout currentTV = new LinearLayout(this);
            currentTV.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 48));
            currentTV.setGravity(Gravity.CENTER_HORIZONTAL);
            currentTV.setId(i);
            final TextView textView = new TextView(this);

            textView.setText(TV[i]);
            textView.setTextSize(18);
            textView.setTextColor(Color.BLACK);
            currentTV.addView(textView);
            currentTV.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(dispensasi.this, fixDispensasi.class);
                    intent.putExtra("data",textView.getText().toString());

                    startActivity(intent);
                }
            });
            linearMAIN.addView(currentTV);
        }


    }


    public static String nopolnya() {
        return tvnopoldisp.getText().toString();
    }

    public void getjenis_disp( String id) {
        final String URL_fix = "http://192.168.43.254/pertamina/macam_dispensasi.php";

        AndroidNetworking.post(URL_fix)
                .addBodyParameter("id",id)
                .setTag("TAG_UPDATE")
                .build().getAsJSONObject(new JSONObjectRequestListener() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("macam_dispensasi");
                    TV = new String[jsonArray.length()];
                    for (int i = 0; i < 1; i++) {

                        for (int x = 0; x <jsonArray.length(); x++) {
                            String hasil = jsonArray.getString(x);
                            TV[x] = hasil;

                        }
                    }
                    panjang = jsonArray.length();
                    Double percentage = ((3-(double)panjang)/3)*100;
                    String fix = String.format(Locale.ENGLISH,"%.2f",percentage);
                    TextView presen = (TextView) findViewById(R.id.presendisp);
                    presen.setText(fix + " %");
                    print();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onError(ANError anError) {

            }
        });
    }

}
