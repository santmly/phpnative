package com.pertamina.trukinspenction.usergrup;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.pertamina.trukinspenction.R;
import com.pertamina.trukinspenction.caritruk_cl;
import com.pertamina.trukinspenction.jadwal_cl;
import com.pertamina.trukinspenction.mt_dispensasi;
import com.pertamina.trukinspenction.today_cl;



public class main_menu_user extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu_user);
        }
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.btDispenn:
                    Intent intent = new Intent(main_menu_user.this, mt_dispensasi.class);
                    startActivity(intent);
                    break;
                case R.id.btCheklist:
                    Intent intent1 = new Intent(main_menu_user.this, jadwal_cl.class);
                    startActivity(intent1);
                    break;
            }
        }

}
