package com.pertamina.trukinspenction;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class starter extends AppCompatActivity {
    private Button btDistri;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.starter);
        btDistri = (Button) findViewById(R.id.btQQ);
        btDistri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUser();
            }
        });
    }

    public void openUser() {
        Intent intent = new Intent(starter.this, user.class);
        startActivity(intent);

    }
}
