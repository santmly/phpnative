package com.pertamina.trukinspenction;

import android.content.Context;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.google.gson.JsonIOException;
import com.pertamina.trukinspenction.usergrup.dispensasi;

import org.json.JSONArray;

public class fixKirimSQL {
    private static final String URL_fix = "http://192.168.43.254/pertamina/fix_update.php";
    private final Context c;

    public fixKirimSQL(Context c) {
        this.c = c;
    }

    public void fix(final String...text) {

        String[] datadarifix = fixDispensasi.datafix();
        String nopol = dispensasi.nopolnya();
        String jenis = fixDispensasi.ambiljenis();

            AndroidNetworking.post(URL_fix)
                    .addBodyParameter("jenis",jenis)
                    .addBodyParameter("nopol", nopol)
                    .addBodyParameter("kondisi", datadarifix[1])
                    .addBodyParameter("dispensasi", datadarifix[2])
                    .addBodyParameter("keterangan", datadarifix[3])
                    .setTag("TAG_UPDATE")
                    .build()
                    .getAsJSONArray(new JSONArrayRequestListener() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response != null) {
                                try {
                                    String responseString = response.toString();
                                    Toast.makeText(c,"PHP SERVER RESPONSE : "+responseString, Toast.LENGTH_SHORT).show();

                                } catch (JsonIOException e)
                                {
                                    e.printStackTrace();
                                    Toast.makeText(c, "GOOD RESPONSE BUT JAVA CAN'T PARSE JSON IT RECEIVED : "+e.getMessage(),Toast.LENGTH_SHORT).show();
                                }
                            }
                        }

                        @Override
                        public void onError(ANError anError) {
                            Toast.makeText(c, "UNSUCCESSFUL : ERROR IS : "+anError.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });
        }

}


