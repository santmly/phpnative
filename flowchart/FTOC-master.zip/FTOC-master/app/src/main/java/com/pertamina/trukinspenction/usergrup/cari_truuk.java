package com.pertamina.trukinspenction.usergrup;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.pertamina.trukinspenction.R;
import com.pertamina.trukinspenction.fixKirimSQL;
import com.pertamina.trukinspenction.menu_admin.hasil_qq;

public class cari_truuk extends AppCompatActivity{
    private String[] namaMT = {"AD 1840 BV", "B 9502 TEI","AB 8624 NE", "AB 8641 NE"};
    public EditText etNopol;
    public static Button btNopol,btvrTruk;
    private Toast toast,toastt,toasttt;

    @Override
    protected void onCreate (Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cari_truuk);
        btNopol = (Button) findViewById(R.id.hasilNopol);
        btvrTruk=(Button) findViewById(R.id.btCariTruk);
        etNopol=(EditText) findViewById(R.id.nopol);
        etNopol.setText("");

        btvrTruk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kerjain();
            }
        });

        btNopol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextclass();
            }
        });
    }

    public void kerjain() {
        String hasNopol = etNopol.getText().toString();
        if (!hasNopol.equals("")) {
            Boolean kondisi = true;

            for (int i = 0; i < namaMT.length; i++) {
                if (hasNopol.equals(namaMT[i])) {
                    btNopol.setText(namaMT[i]);
                    btNopol.setVisibility(View.VISIBLE);
                    toasttt =  Toast.makeText(this,"Nomor Polisi Ditemukan!", Toast.LENGTH_SHORT);
                    toasttt.setGravity(Gravity.TOP,0,100);
                    toasttt.show();
                    kondisi=false;
                }
            }
            if(kondisi){
                toastt = Toast.makeText(this,"Nomor Polisi Tidak Ada", Toast.LENGTH_SHORT);
                toastt.setGravity(Gravity.TOP,0,100);
                toastt.show();
            }
        }
        else {
            toast = Toast.makeText(this, "Masukkan Nomor Polisi!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP, 0, 100);
            toast.show();
        }
    }

    public void nextclass() {
        String nopol = btNopol.getText().toString();

        Intent i = new Intent(cari_truuk.this, dispensasi.class);
        i.putExtra("data", nopol);
        startActivity(i);
    }


}




