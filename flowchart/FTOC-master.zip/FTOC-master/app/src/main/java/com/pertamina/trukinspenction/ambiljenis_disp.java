package com.pertamina.trukinspenction;

import android.content.Context;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.google.gson.JsonIOException;

import org.json.JSONArray;

public class ambiljenis_disp {
    private static final String URL_fix = "http://192.168.43.254/pertamina/macam_dispensasi.php";
    private final Context c;

    public ambiljenis_disp(Context c) {
        this.c = c;
    }


}
