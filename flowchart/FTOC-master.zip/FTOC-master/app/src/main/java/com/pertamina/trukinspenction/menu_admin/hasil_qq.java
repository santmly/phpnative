package com.pertamina.trukinspenction.menu_admin;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.pertamina.trukinspenction.R;
import com.pertamina.trukinspenction.initialVar;
import com.pertamina.trukinspenction.usergrup.dispensasi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class hasil_qq extends AppCompatActivity{
    private RequestQueue rq;
    private String[] id = new String[] {"qmaber1","qkon1","qdispen1","qket1","qmaber2","qkon2","qdispen2","qket2",
            "qkon3","qdispen3","qket3"};
    private String[] nKolom = new String[] {"simb_masa_berlaku","simb_kondisi","simb_dispensasi","simb_keterangan",
            "stm_masa_berlaku","stm_kondisi","stm_dispensasi","stm_keterangan",
            "btrk_kondisi","btrk_dispensasi","btrk_keterangan"};

    private TextView[] daftarId;
    private TextView tbaik,nopolqq;
    private int temp;
    private int banyakJenis = 0;
    public int tidakbaik = 0;
    initialVar s = new initialVar();

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hasil_qq);
        Button bt = findViewById(R.id.btParse);
        rq = Volley.newRequestQueue(this);

        nopolqq = (TextView) findViewById(R.id.Nopolqq);
        Intent intent = getIntent();
        String data = intent.getStringExtra("data");
        nopolqq.setText(data);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jsonParse();

                   }
        });
        }
        private void jsonParse()
        {
            String url = "http://192.168.100.5/pertamina/connn.php";


            JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    try {

                        JSONArray jsonArray = response.getJSONArray("Mobil 1");
                        daftarId =  new TextView[11];
                        for (int i = 0; i<1; i++) {

                            JSONObject hasil = jsonArray.getJSONObject(i);
                            for (int x=0;x<11; x++)
                            {
                                temp = getResources().getIdentifier(id[x],"id",getPackageName());
                                daftarId[x] = (TextView) findViewById(temp);
                                String result = hasil.getString(nKolom[x]);
                                if (result.equals("1")) { result = "Baik"; banyakJenis = banyakJenis + 1;}
                                else if (result.equals("0"))
                                { result = "Tidak baik";
                                banyakJenis = banyakJenis+1;
                                daftarId[x].setBackgroundColor(Color.RED); tidakbaik =tidakbaik +1;}
                                daftarId[x].append(result);
                                }



                            }
                        s.setYangkurang(tidakbaik);
                        Double persen = ((double)tidakbaik/3)*100;
                        String persenn = String.format(Locale.ENGLISH,"%.2f", persen);
                        tbaik=(TextView) findViewById(R.id.tidakbaik);
                        tbaik.setText(persenn);



                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    error.printStackTrace();
                }
            });
            rq.add(request);


        }


}
