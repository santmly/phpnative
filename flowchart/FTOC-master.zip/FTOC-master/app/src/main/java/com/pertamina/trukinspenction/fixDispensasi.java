package com.pertamina.trukinspenction;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.opengl.Visibility;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

import javax.xml.transform.sax.SAXTransformerFactory;

    public class fixDispensasi extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {
        public LinearLayout maberfix, kondisifix, keteranganfix;
        public TextView labelfix, datefix, maberll,etKetfix;
        public CheckBox cbBaikfix;
        public Spinner dd1;
        public static String jenisnya;
        public Button btfixx;
        public static String[] datafixx;



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.fix_dispensasi);

            labelfix = (TextView) findViewById(R.id.labelfix); maberll = (TextView) findViewById(R.id.maberll); etKetfix=(TextView) findViewById(R.id.etketfix);
            datefix = (TextView) findViewById(R.id.datefix); cbBaikfix= (CheckBox) findViewById(R.id.cbBaikfix);
            maberfix = (LinearLayout) findViewById(R.id.maberfix);
            kondisifix = (LinearLayout) findViewById(R.id.kondisifix);
            keteranganfix = (LinearLayout) findViewById(R.id.keteranganfix);
            dd1 = (Spinner) findViewById(R.id.spfix);
            btfixx  = (Button) findViewById(R.id.btfixdisen);
            Intent i = getIntent();
            String dataJenis = i.getStringExtra("data");


            if (dataJenis.equals("SIM B I_B II")) {
                jenisnya = "simb";
            } else if(dataJenis.equals("Surat Tera Metrologi")) {
                jenisnya = "stm";
            } else if (dataJenis.equals("Baut Tera Ruang Metrologi")) {
                jenisnya = "baut tera";
            }
            labelfix.setText(dataJenis);
            datefix.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDate();
                }
            });
            inisialView();
            ambiljenis();
            jenissp();
            kirimkedatabase();
            datafix();
        }

            private void showDate () {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        this,
                        this,
                        Calendar.getInstance().get(Calendar.YEAR),
                        Calendar.getInstance().get(Calendar.MONTH),
                        Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
                );
                datePickerDialog.show();
            }


            @Override
            public void onDateSet (DatePicker view,int year, int month, int dayOfMonth){
                month = month + 1;
                String date = dayOfMonth + "-" + month + "-" + year;
                datefix.setText(date);
            }
        public void jenissp()
        {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item);

            adapter.add("-"); adapter.add("1"); adapter.add("2"); adapter.add("3"); adapter.add("5"); adapter.add("6"); adapter.add("7");
            adapter.add("10"); adapter.add("15"); adapter.add("30");

            dd1.setAdapter(adapter); dd1.setSelection(0);

        }
        public void inisialView() {
            etKetfix=(TextView) findViewById(R.id.etketfix);
            cbBaikfix= (CheckBox) findViewById(R.id.cbBaikfix);

        }

        public static  String[] datafix (){

            return datafixx;

        }
        public static String ambiljenis() {

            return jenisnya;
        }

        public void kirimkedatabase() {

            btfixx.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                        datafixx = new String[4];
                        datafixx[0] = datefix.getText().toString();
                        if (cbBaikfix.isChecked()) {
                            datafixx[1] = "1";
                        } else {
                            datafixx[1] = "0";
                        }
                        datafixx[2] = dd1.getSelectedItem().toString();
                        datafixx[3] = etKetfix.getText().toString();

                    new fixKirimSQL(fixDispensasi.this).fix(datafixx[1],datafixx[2],datafixx[3]);
                }
            });

        }
    }
