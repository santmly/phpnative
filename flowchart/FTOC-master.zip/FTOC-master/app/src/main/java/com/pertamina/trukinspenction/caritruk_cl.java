package com.pertamina.trukinspenction;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.pertamina.trukinspenction.usergrup.cari_truuk;
import com.pertamina.trukinspenction.usergrup.dispensasi;

public class caritruk_cl extends Activity {
    private String[] namaMT = {"AD 1840 BV", "B 9502 TEI","AB 8624 NE", "AB 8641 NE"};
    public EditText etNopol_cl;
    public Button btNopol_cl,btvrTruk_cl;
    private Toast toast,toastt,toasttt;

    @Override

    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.caritruk_cl);
        btNopol_cl = (Button) findViewById(R.id.hasilNopol_cl);
        btvrTruk_cl=(Button) findViewById(R.id.cari_cl);
        etNopol_cl=(EditText) findViewById(R.id.nopol_cl);
        etNopol_cl.setText("");

        btvrTruk_cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { caritruk();
            }
        });

        btNopol_cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextclass();
            }
        });
    }

    public void caritruk() {
        String hasNopol = etNopol_cl.getText().toString();
        if (!hasNopol.equals("")) {
            Boolean kondisi = true;

            for (int i = 0; i < namaMT.length; i++) {
                if (hasNopol.equals(namaMT[i])) {
                    btNopol_cl.setText(namaMT[i]);
                    btNopol_cl.setVisibility(View.VISIBLE);
                    toasttt =  Toast.makeText(this,"Nomor Polisi Ditemukan!", Toast.LENGTH_SHORT);
                    toasttt.setGravity(Gravity.TOP,0,100);
                    toasttt.show();
                    kondisi=false;
                }
            }
            if(kondisi){
                toastt = Toast.makeText(this,"Nomor Polisi Tidak Ada", Toast.LENGTH_SHORT);
                toastt.setGravity(Gravity.TOP,0,100);
                toastt.show();
            }
        }
        else {
            toast = Toast.makeText(this, "Masukkan Nomor Polisi!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP, 0, 100);
            toast.show();
        }
    }

    public void nextclass() {
        String nopol = btNopol_cl.getText().toString();

        Intent i = new Intent(caritruk_cl.this,today_cl.class);
        i.putExtra("data", nopol);
        startActivity(i);
    }
}
