package com.pertamina.trukinspenction;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.pertamina.trukinspenction.R;
import com.pertamina.trukinspenction.backgroundWorker;
import com.pertamina.trukinspenction.menu_admin.backgroundWorker1;

public class login extends AppCompatActivity {
    EditText UsernameET, PasswordET;
    Button user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UsernameET = findViewById(R.id.etUsername);
        PasswordET = findViewById(R.id.etPassword);
        user = (Button) findViewById(R.id.btnLogin);


        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLoginuser(v);
            }
        });
    }

    public void onLoginuser (View view) {
        String username = UsernameET.getText().toString();
        String password = PasswordET.getText().toString();
        String type = "login";

        backgroundWorker backgroundWorke = new backgroundWorker(this);
        backgroundWorke.execute(type, username, password);
    }

}
