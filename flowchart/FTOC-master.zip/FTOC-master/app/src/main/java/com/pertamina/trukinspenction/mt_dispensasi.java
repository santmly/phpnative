package com.pertamina.trukinspenction;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.pertamina.trukinspenction.usergrup.dispensasi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class mt_dispensasi extends AppCompatActivity {
    public Integer panjang;
    private LinearLayout linearMAIN;
    private String[] jmlnopol;
    private RequestQueue rq;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mt_dispensasi);
        rq = Volley.newRequestQueue(this);
        linearMAIN = (LinearLayout) findViewById(R.id.LL_disp);
        ambildata();
    }
    private void print() {
        for (int i = 0; i < panjang; i++) {
            LinearLayout currentTV = new LinearLayout(this);
            currentTV.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 48));
            currentTV.setGravity(Gravity.CENTER_HORIZONTAL);
            currentTV.setId(i);
            final TextView textView = new TextView(this);

            textView.setText(jmlnopol[i]);
            textView.layout(0,0,0,5);
            textView.setTextSize(18);
            textView.setTextColor(Color.BLACK);
            currentTV.addView(textView);
            currentTV.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mt_dispensasi.this, dispensasi.class);
                    intent.putExtra("dataku", textView.getText().toString());
                    startActivity(intent);
                }
            });
            linearMAIN.addView(currentTV);
        }
    }
    public void ambildata() {

        String url =  "http://192.168.43.254/pertamina/mt_dispensasi.php";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("mt_dispensasi");
                    jmlnopol = new String[jsonArray.length()];
                    for (int i = 0; i < 1; i++) {

                        for (int x = 0; x <jsonArray.length(); x++) {
                            String hasil = jsonArray.getString(x);
                            jmlnopol[x] = hasil;

                        }
                    }
                    panjang = jsonArray.length();
                    print();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        rq.add(request);

    }


}
