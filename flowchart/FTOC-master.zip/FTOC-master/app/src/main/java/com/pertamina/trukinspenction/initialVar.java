package com.pertamina.trukinspenction;

public class initialVar {
    private String SIMB1,STM;
    private String Dispen1, Dispen2,Dispen3,Dispen4,
                    Dispen5,Dispen6,Dispen7,Dispen8,
                    Dispen9,Dispen10,Dispen11;
    private String Keterangan1,Keterangan2,Keterangan3,Keterangan4,
                    Keterangan5,Keterangan6,Keterangan7,Keterangan8,
                    Keterangan9,Keterangan10,Keterangan11;
    private int Kondisi1,Kondisi2,Kondisi3,Kondisi4,
                    Kondisi5,Kondisi6,Kondisi7,Kondisi8,
                    Kondisi9,Kondisi10,Kondisi11;
    private int yangkurang;
    private String jenis_pemeriksaan[] = {"SIM B","STM","Baut Tera"};
    private String idne;

    public String getJenis_pemeriksaan(int i)
    {
        return jenis_pemeriksaan[i];
    }

    public String getIdne() {return idne;}public void setIdne(String id) {this.idne = id;}

    public String getSIMB1() {return SIMB1;} public void setSIMB1(String SIMB1) {this.SIMB1 = SIMB1;}
    public String getSTM(){ return STM;} public void setSTM(String STM) {this.STM = STM;}

    public int getKondisi1() {return Kondisi1;} public void setKondisi1(int kondisi1) {this.Kondisi1 = kondisi1;}
    public int getKondisi2() {return Kondisi2;} public void setKondisi2(int kondisi2) {this.Kondisi2 = kondisi2;}
    public int getKondisi3() {return Kondisi3;} public void setKondisi3(int kondisi3) {this.Kondisi3 = kondisi3;}
    public int getKondisi4() {return Kondisi4;} public void setKondisi4(int kondisi4) {this.Kondisi4 = kondisi4;}
    public int getKondisi5() {return Kondisi5;} public void setKondisi5(int kondisi5) {this.Kondisi5 = kondisi5;}
    public int getKondisi6() {return Kondisi6;} public void setKondisi6(int kondisi6) {this.Kondisi6 = kondisi6;}
    public int getKondisi7() {return Kondisi7;} public void setKondisi7(int kondisi7) {this.Kondisi7 = kondisi7;}
    public int getKondisi8() {return Kondisi8;} public void setKondisi8(int kondisi8) {this.Kondisi8 = kondisi8;}
    public int getKondisi9() {return Kondisi9;} public void setKondisi9(int kondisi9) {this.Kondisi9 = kondisi9;}
    public int getKondisi10() {return Kondisi10;} public void setKondisi10(int kondisi10) {this.Kondisi10 = kondisi10;}
    public int getKondisi11() {return Kondisi11;} public void setKondisi11(int kondisi11) {this.Kondisi11 = kondisi11;}

    public int getYangkurang() {return yangkurang;} public void setYangkurang(int x) {yangkurang = x;}

    public String getDispen1() {return Dispen1;} public void setDispen1(String Dispen1) {this.Dispen1 = Dispen1;}
    public String getDispen2() {return Dispen2;} public void setDispen2(String Dispen2) {this.Dispen2 = Dispen2;}
    public String getDispen3() {return Dispen3;} public void setDispen3(String Dispen3) {this.Dispen3 = Dispen3;}
    public String getDispen4() {return Dispen4;} public void setDispen4(String Dispen4) {this.Dispen4 = Dispen4;}
    public String getDispen5() {return Dispen5;} public void setDispen5(String Dispen5) {this.Dispen5 = Dispen5;}
    public String getDispen6() {return Dispen6;} public void setDispen6(String Dispen6) {this.Dispen6 = Dispen6;}
    public String getDispen7() {return Dispen7;} public void setDispen7(String Dispen7) {this.Dispen7 = Dispen7;}
    public String getDispen8() {return Dispen8;} public void setDispen8(String Dispen8) {this.Dispen8 = Dispen8;}
    public String getDispen9() {return Dispen9;} public void setDispen9(String Dispen9) {this.Dispen9 = Dispen9;}
    public String getDispen10() {return Dispen10;} public void setDispen10(String Dispen10) {this.Dispen10 = Dispen10;}
    public String getDispen11() {return Dispen11;} public void setDispen11(String Dispen11) {this.Dispen11 = Dispen11;}


    public String getKeterangan1() {return Keterangan1;} public void setKeterangan1(String keterangan1) {this.Keterangan1 = keterangan1;}
    public String getKeterangan2() {return Keterangan2;} public void setKeterangan2(String keterangan2) {this.Keterangan2 = keterangan2;}
    public String getKeterangan3() {return Keterangan3;} public void setKeterangan3(String keterangan3) {this.Keterangan3 = keterangan3;}
    public String getKeterangan4() {return Keterangan4;} public void setKeterangan4(String keterangan4) {this.Keterangan4 = keterangan4;}
    public String getKeterangan5() {return Keterangan5;} public void setKeterangan5(String keterangan5) {this.Keterangan5 = keterangan5;}
    public String getKeterangan6() {return Keterangan6;} public void setKeterangan6(String keterangan6) {this.Keterangan6 = keterangan6;}
    public String getKeterangan7() {return Keterangan7;} public void setKeterangan7(String keterangan7) {this.Keterangan7 = keterangan7;}
    public String getKeterangan8() {return Keterangan8;} public void setKeterangan8(String keterangan8) {this.Keterangan8 = keterangan8;}
    public String getKeterangan9() {return Keterangan9;} public void setKeterangan9(String keterangan9) {this.Keterangan9 = keterangan9;}
    public String getKeterangan10() {return Keterangan10;} public void setKeterangan10(String keterangan10) {this.Keterangan10 = keterangan10;}
    public String getKeterangan11() {return Keterangan11;} public void setKeterangan11(String keterangan11) {this.Keterangan11 = keterangan11;}

    public String toString() {return SIMB1;}


}
